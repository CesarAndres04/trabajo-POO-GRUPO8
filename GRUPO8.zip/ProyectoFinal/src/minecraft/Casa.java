package minecraft;
import java.awt.Color;
import java.awt.Graphics;
public class Casa implements baseDibujo {
    @Override
    public void Dibujar(Graphics g){
        g.setColor(new Color(128,64,0));
        g.fillRect(400, 150, 200, 130);
        g.fillRect(400, 130, 40, 40);
        
    }
    
}
