package minecraft;

import java.awt.Color;
import java.awt.Graphics;

public class Cielo implements baseDibujo {
    @Override
    public void Dibujar(Graphics g){
        g.setColor(new Color(81,209,246));
        g.fillRect(0,0,660,330);
    }
    
}
