package minecraft;
import java.awt.Color;
import java.awt.Graphics;
public class Lago implements baseDibujo {
    @Override
    public void Dibujar(Graphics g){
        g.setColor(Color.BLUE);
        g.fillRect(0, 300, 1000, 150);
    }
    
}
