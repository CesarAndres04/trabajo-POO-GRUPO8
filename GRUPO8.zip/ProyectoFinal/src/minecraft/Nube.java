package minecraft;
import java.awt.Color;
import java.awt.Graphics;
public class Nube implements baseDibujo {
    @Override
    public void Dibujar(Graphics g){
        g.setColor(Color.WHITE);
        g.fillRect(450, 10, 100, 30);
        g.fillRect(400, 30, 100, 30);
        g.fillRect(500, 30, 100, 30);
    }
    
}
