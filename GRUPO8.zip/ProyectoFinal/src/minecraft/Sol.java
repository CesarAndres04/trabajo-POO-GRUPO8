package minecraft;

import java.awt.Color;
import java.awt.Graphics;

public class Sol implements baseDibujo {
    @Override
    public void Dibujar(Graphics g){
        g.setColor(Color.YELLOW);
        g.fillOval(20, 20, 120, 120);
    }
    
}
