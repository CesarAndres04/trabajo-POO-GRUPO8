package minecraft;

import java.awt.Color;
import java.awt.Graphics;

public class Superficie implements baseDibujo {
    @Override
    public void Dibujar(Graphics g){
        g.setColor(Color.green);
        g.fillRect(0, 250, 1200, 150);
    }
    
}
