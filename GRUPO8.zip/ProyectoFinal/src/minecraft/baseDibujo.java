package minecraft;

import java.awt.Graphics;

public interface baseDibujo {
    void Dibujar(Graphics g);
}

